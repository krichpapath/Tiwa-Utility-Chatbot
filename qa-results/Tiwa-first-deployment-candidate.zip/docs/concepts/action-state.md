# Action state

## What this is

`pipeline._doing()` reads live state and tells her what she is actually doing right now —
when she's doing something. Today that means music. It's the extension point for anything
she gains later.

**Doing nothing says nothing.** On an ordinary turn it returns `""` and adds not one token
to her context.

## Why it's here

Two bugs, one cause: **her own actions weren't in her context.**

- She had to spend a tool call (`now_playing`) to learn what she was playing.
- She'd say *"เปิดละ"* (put it on) with nothing queued — three turns running — because
  pass 1 wrote *"putting it on now"* in its brief and pass 2 believed it.

Writing an intention is not doing a thing. So what's true is now decided from live
state, in code, and handed to her whether she asks or not.

## Diagram

```mermaid
stateDiagram-v2
    [*] --> Silent
    Silent --> Playing : play_music queued<br/>+ bot.py flush
    Playing --> Playing : queue_music (appends)
    Playing --> Playing : skip_music (next track)
    Playing --> Silent : stop_music
    Playing --> Silent : track ends, queue empty
    Playing --> Silent : leave_voice (deck cleared)
    note right of Silent
        _doing() says nothing —
        except on a turn that
        asked for music and
        got none
    end note
    note right of Playing
        _doing() says:
        "you are playing X.
        Queued next: Y"
    end note
```

<figcaption>She is told when she is doing something. Silence is not narrated at her.</figcaption>

## How it works here

```python
def _doing(missed_music: bool = False, blind: bool = False) -> str:
    out = []
    if music.NOW["title"]:
        # "You are playing X right now. Queued next: Y. You know this
        #  without looking it up — if they ask what is on, just tell them."
    if queued:      # what she set in motion THIS turn
        # "You have just done this: play bad apple. It IS happening."
    elif missed_music:
        # "They asked for music but the search came up empty and nothing
        #  is queued — do NOT say you are putting a song on."
    if blind:
        # "They sent an image and your eyes did not work this time — you
        #  genuinely cannot see it. Do NOT guess what is in it."
    if tools.PENDING_LEAVE:
        # "You are leaving the voice channel as you say this."
    return " ".join(out)      # "" on a quiet turn
```

The output goes into pass 2's `[inner-state]` block, and `respond()` skips the append
entirely when it's empty. Three jobs in one function:

1. **What's playing** — so she never needs a tool call to know her own deck.
2. **What she just queued** — so she confirms it instead of denying it. This also
   carries "you don't need to recognise a song to put it on", which fixed her saying
   *"never heard of it"* while the track was already starting.
3. **What is *not* happening** — but only on a turn that asked for music and got none.

### The retry does not care what's already playing

`_missed_music()` fires on any music ask with no music tool called — **including while a
song is on**. It briefly didn't, and that was a real bug: the guard silently switched the
retry off for *"put on a different one"*, which is most music turns.

The deck was the wrong thing to check. The right guard is [the question
check](#a-question-is-not-a-request), and it took a second live failure to find.

The live log caught it: three confabulated turns in one session, every one with a song
already playing.

| she was told | she said | tool fired |
|---|---|---|
| `เปิดเพลงปล้น` | "เปิดให้แล้ว เพลงปล้น ของ Bodyslam" | none |
| `ให้โอกาสอีกรอบเปิดเพลงให้ถูก` | "เปิดเพลง You doom us all ให้แล้ว" | none |

Note what *didn't* save her: `_doing()` correctly told her she was playing
*"Lamenting the Days"*, and she claimed a different song anyway. True information in the
prompt does not beat a tool that actually runs. **Prompts reduce, code decides.**

### The retry only fires if the trigger matches {#a-question-is-not-a-request}

The bug came back, because the trigger list was the weak part all along. It held request
*phrases* — `เปิดเพลง`, `play some` — and missed the most ordinary ask there is: a bare
imperative with a title after it. Four turns in one session, every one silent:

| she was told | tool fired | retry fired |
|---|---|---|
| `play ビビデバ - BIBBIDIBA` | none | none |
| `Queue เพลง ビビデバ - BIBBIDIBA` | none | none |
| `play tung tung tung sahur orchestra` | none | none |

So the trigger matched a verb at the **start** of the message. Anchored, because a bare
`play` substring also matches *"my dad plays Warframe"* and would have put on a random song.

!!! note "Anchoring is gone — the veto moved"
    That anchoring is what made her deaf to the bare word `skip`, four times in her own
    log. `_maybe_music()` is greedy now and *"my dad plays Warframe"* does reach DJ Tiwa
    — which answers `none`, so nothing plays. Measured in `djminibench --live`; it caught
    DJ getting that exact sentence wrong on the first run, and the fix was DJ's prompt.
    See [the swarm](the-swarm.md) and [ADR-029](../reference/decisions.md#adr-029).

And the same session produced the mirror failure, which is worse:

| she was told | what happened |
|---|---|
| `ตอนนี้เปิดเพลงอะไรอยู่` (*what song is on?*) | matched `เปิดเพลง` → the retry searched that literal sentence → played an unrelated Thai song over her answer |

**Asking about music is not asking for music.** `_QUESTION` now short-circuits the retry.
It holds phrases rather than the bare word `อะไร`, because *"เปิดอะไรก็ได้"* (put on
anything) is a real request and would otherwise be swallowed.

Both directions are locked in `tests/djbench.py` using the exact strings from the log —
that table fails 4/4 against the old trigger.

### She is told the deck is empty only when asked {#empty-deck}

`_doing()` says nothing about music on a silent turn — and that left her with **zero
state on the one turn it matters**: someone asks what's on while nothing is playing, and
she names a song. There is no live state saying "nothing", so the persona fills the gap.

The fix keeps the narrowness. `_asked_deck()` matches the same deck-question phrases the
retry already uses to veto itself (`_DECK_Q`), and only then does `_doing()` say the deck
is empty. An ordinary quiet turn still costs nothing.

The phrase list is deliberately made of *phrases*, never the bare word `อะไร` — a looser
`เพลงอะไร` swallows `เปิดเพลงอะไรก็ได้` ("put on anything"), which is a real request. That
one is asserted in `djbench.py`, because it broke there the moment it was written too
loosely.

### The negative is narrow on purpose

It used to say "no music is playing" on *every* quiet turn. That's a rule about music
riding along on messages that have nothing to do with music — paid for constantly, used
almost never, and one more line competing for attention in a block that already holds her
language, her pronouns and her mood.

So it now fires only when `_missed_music()` said she was asked **and**
[`_force_music()`](../surfaces/music.md) came up empty too. On a turn where the forced
retry worked, job 2 covers it and the negative stays quiet.

The guard didn't get weaker: the case it defended against is now caught in code before the
prompt ever sees it. Prompts reduce, code decides.

The `blind` flag is the same negative in a second place. [`eyes.look()`](../surfaces/eyes.md)
returns `""` rather than raising when the vision call fails, and `respond()` passes
`blind=bool(images) and not seen`. It fires on exactly the turns where an image arrived and
she cannot see it — never as a standing "you have no eyes". Bluffing about a picture that's
right there in the channel is caught instantly, which is why it's worth the tokens on those
turns and no others.

### `now_playing` was deleted

Once the deck is in her context every turn, a tool that reports the deck is a wasted
round-trip. Removing it also removed one competitor for the model's attention — and
missing `play_music` was an active bug at the time.

`turn_context()` later did the same thing for memory: what she should already know is
injected, not asked for. Same trade, same reason.

### Adding a future feature

One `if` per subsystem. When she gains lights, timers, or a download:

```python
if lights.ON:
    out.append(f"The {lights.WHERE} lights are on because you turned them on.")
```

No registry, no state machine, no event bus. The rule that matters is the one already
holding: **read live state, never what the model believes it did.**

## Gotchas

- **It's still a prompt.** `_doing()` puts *true* information in front of her, but
  nothing forces her to respect it. She was observed role-playing
  `*puts on some upbeat music*` with nothing queued, roughly 1 turn in 6. The code-level
  fix landed as [`_force_music()`](../surfaces/music.md) — on a missed ask the song is
  now really queued, so what she says becomes true instead of being argued with.
- **Nothing is asserted about silence.** A quiet turn returns `""`, which means a
  subsystem you forget to add a line for is indistinguishable from one that's idle. Add
  the `if` at the same time as the feature.
- **Lazy import of `tiwa.music`** inside the function, so `chat.py` and the benches
  don't drag in PyAV and numpy.
- **`music.NOW` is one global deck**, not per-guild. Two simultaneous voice calls would
  read each other's state.
- **Clearing the deck is `bot.py`'s job.** `_hang_up()` does it, because disconnecting
  kills the audio but leaves `NOW` claiming a song is on.

## Go deeper

- [Music and the DJ](../surfaces/music.md) — what sets this state.
- [Search and curiosity](search.md) — the other half of "don't claim what isn't true".
- [Her persona](persona.md) — where the output lands.
- [Actuators](tools.md) — why fewer things to choose between is better.
