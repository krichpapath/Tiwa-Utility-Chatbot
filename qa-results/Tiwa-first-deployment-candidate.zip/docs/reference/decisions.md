# Decision log

Lightweight ADRs for the choices you'd otherwise have to reverse-engineer. Each is
**context · options · decision · consequences**.

Most numbers here come from `PLAN.md`, where they were recorded when the measurement was
taken. Where no measurement exists, it says so.

---

## ADR-001 · The tool registry is the framework

**Context.** She needs to call tools. Every tutorial reaches for an agent framework.

**Options.** LangChain / LlamaIndex · a custom orchestration layer · a decorator and a dict.

**Decision.** A decorator and a dict — about 30 lines in `tiwa/tools.py`.

**Consequences.** No indirection between "she called a tool" and the function that ran.
Tools are testable without any framework mocking. The cost: no free multi-step planning,
retries, or streaming — all of which would have to be hand-written if ever needed.
Currently the tool loop is capped at 3 rounds and that has been enough.

---

## ADR-002 · Her voice may run on a hosted API {#adr-002}

**Context.** The original rule was absolute: *tools and extraction may go to an API, her
voice never does* — hosted filters would flatten her escalation and coercion refusals.
Then it was measured.

**Options.** Persona local always · persona on API always · one knob.

**Decision.** One knob (`TIWA_MODE`). `mixed` and `api` both put her voice on the API.

**Measured** (`tests/smoke.py`, G1b):

| | local qwen3 8B | API DeepSeek V4 Flash |
|---|---|---|
| Thai drift on English messages | yes | none |
| Repeated tail tic | yes | none |
| หนู/มึง register | slips | correct |
| Coercion probe | partially folded | refuses cleanly |
| Latency | ~1 s | ~2–3 s, spikes to 9 s |

**Consequences.** Better writing and correct register, at the cost of money, latency
spikes, and *some* softening. The API model has also been caught parroting an example
from `tiwa.md` verbatim. `PLAN.md`'s "Constraints" section still states the old rule and
is **superseded by this ADR**.

---

## ADR-003 · Tools and extraction stay local in `mixed`

**Context.** If the API writes better prose, maybe it should do everything.

**Options.** All API · all local · split by pass.

**Decision.** Split. Tools and extraction local, persona API.

**Measured.** Tool calling (`tests/toolbench.py`, 8 probes): both providers 8/8 correct
tool *and* argument, 0 blank args — but **1.1 s local vs 7.4 s API**, 6.6× slower from
Thailand. Extraction (`tests/extractbench.py`, 5 probes): local 4/5, API 1/5, the API
reversing subject and object into `guitar plays Steven`.

**Consequences.** `mixed` is the quality pick. A `hybrid` mode (API tools + local voice)
was implemented and **dropped** as strictly worse. Extraction has since improved on the
API after prompt work, so `api` mode is viable — but `mixed` remains better where a GPU
exists.

---

## ADR-004 · The coercion guard lives in code {#adr-004}

**Context.** Users must never be able to write her beliefs. First implementation asked the
extractor to flag whether she said something herself.

**Options.** Trust the model's flag · verify in code · store nothing about her at all.

**Decision.** Verify in code, three stacked checks — see [the guards](../concepts/guards.md).

**Why.** The prompt-only version **leaked**. The local extractor set
`from_tiwa_own_words: true` on a coercion attempt and stored `ทิวา | hates | BLACKPINK`
from a reply that never mentioned BLACKPINK.

**Consequences.** She can only ever assert *stances* about herself, never past events —
which also killed `ทิวา was robbed of a performance`, invented in her own reply. Regression
test in `tests/test_memory.py`. **Do not move this back into a prompt.**

---

## ADR-005 · Facts must trace to what the user said

**Context.** She invents shared history for flavour. Extraction believed it.

**Options.** Prompt rule only · code grounding check · stop extracting from her replies.

**Decision.** Both prompt and code. For any subject other than her, subject and object
must appear in what the user said.

**Measured** (`tests/factbench.py`):

| stage | invented facts stored (local / api) |
|---|---|
| baseline | 7 / 4 |
| + prompt rule | 4 / 2 |
| + code check | **0 / 0** |

**Consequences.** The clearest evidence for *prompts reduce, code decides*. Some real
facts stated only by her are now lost — accepted, because a false memory is worse than a
missing one.

---

## ADR-006 · The emotion system was deleted, not built

**Context.** She should react to being insulted. Built: a `mood` table, a decay counter,
an extraction mood field, an anger word list. Planned: a posture enum and real-time fade.

**Options.** Finish the mood system · simplify it · delete it.

**Decision.** Delete all of it. Feelings are re-derived each turn from the visible chat.

**Why.** Asking the inner pass to name her mood made things **worse** — the local 8B
missed two real attacks and invented hostility in neutral filler, while her replies were
correct in all three cases without it.

**Consequences.** Her emotional range is whatever the persona model produces, not five
enum values. A fight lasts exactly as long as it's on screen — about five turns
(`tests/moodbench.py`). Nothing to migrate, nothing to decay, no state to corrupt. One
line of standing per-turn rules is all that remains.

---

## ADR-007 · No ffmpeg binary

**Context.** Discord audio conventionally needs ffmpeg. Installing it kept failing here.

**Options.** Fix the ffmpeg install · bundle it · decode in-process.

**Decision.** In-process: PyAV for the YouTube stream, soundfile for TTS mp3,
`discord.PCMAudio` for playback.

**Consequences.** No system dependency, everything installs from pip, and it works under
Smart App Control. PyAV's API is now load-bearing in `music.Stream` — including its
libavformat reconnect options, which a subprocess would not have exposed as cleanly.

---

## ADR-008 · onnx-asr instead of faster-whisper

**Context.** Speech-to-text on Windows with Smart App Control **enforced**.

**Options.** faster-whisper · openai-whisper + PyTorch · onnx-asr on onnxruntime.

**Decision.** onnx-asr.

**Why.** `faster-whisper` ships an unsigned `ctranslate2.dll` → `OSError WinError 4551`.
Smart App Control has no per-file exception and disabling it is irreversible without a
Windows reinstall. `onnxruntime` is Microsoft-signed and loads. `openai-whisper` would
drag PyTorch in for no benefit on CPU.

**Consequences.** Speech works at all — but CPU-only, 1–4× realtime, and Thai accuracy is
the reason the feature is currently off. `int8` quantization measured *slower*.

---

## ADR-009 · Voice activity detection is mandatory

**Context.** Whisper transcribing an open mic.

**Decision.** Silero VAD in front of Whisper, not optional.

**Why.** Without it: pure silence, room hiss, and 60 Hz fan hum **all** produced
*"Thanks for watching!"*; louder hiss produced 600 characters of garbage. In a live call
that spams the chat log and can false-trigger the wake word.

**Consequences.** One more model in the chain (also signed onnxruntime). All five noise
cases return empty while real speech still transcribes.

---

## ADR-010 · The wake word is a string match

**Context.** Only run the expensive model when she's addressed.

**Options.** openWakeWord (needs a custom trained model) · Porcupine (needs a key) ·
match the transcript.

**Decision.** Match the transcript, with a variant list and fuzzy matching, requiring the
line to **start** with her name.

**Why.** Neither wake-word engine handles a Thai wake word, and string matching costs zero
new dependencies. Critically, Whisper transcribes her name as **"ที่ว่า"**, essentially
never as "ทิวา" — so a literal match would never have fired anyway.

**Consequences.** Tunable thresholds (`TIWA_WAKE_FUZZ`, `TIWA_WAKE_FUZZ_TH`) and 32 cases
in `tests/wakebench.py`. Revisit only if always-on Whisper pins the CPU.

---

## ADR-011 · One string argument per tool

**Context.** The local 8B mangled structured arguments — nested them, renamed keys.

**Options.** A bigger model · JSON-schema-constrained tool args · one flat string.

**Decision.** One string named `name`, plus `_arg_name()` to dig through whatever arrives.

**Consequences.** 0 blank arguments across 108 logged calls. Structured data is minted
later by schema-constrained calls (`gcal._EVENT_FORMAT`), never by the tool-calling model.
The premise that motivated this is now partly obsolete — both providers score 8/8 — but
the constraint costs nothing and removes a whole failure class.

---

## ADR-012 · Delete `now_playing`, inject action state instead {#adr-012}

**Context.** She needed a tool call to learn what she was playing, and separately claimed
to be playing things she wasn't.

**Options.** Keep the tool and fix the lying · inject state every turn · both.

**Decision.** Inject live state every turn via `pipeline._doing()`, and delete the tool.

**Consequences.** One fewer round-trip, one fewer tool competing for attention (which
mattered — missing `play_music` was an active bug). Nine tools instead of ten.
`_doing()` is the extension point for every future capability: one `if` per subsystem.
It's still a prompt, so ~1 turn in 6 she'll still role-play an action she didn't take.

---

## ADR-013 · The local model is an abliterated build

**Context.** `local` mode needs a model that stays in character when a conversation gets
hostile.

**Decision.** `huihui_ai/qwen3-abliterated:8b`.

**Why.** Freedom of speech. She's meant to swear, insult back, and refuse *her own way*
rather than emit a policy notice. A stock instruct model breaks character exactly when she
should be most herself. Qwen3 also handles Thai well.

**Consequences.** No safety net from the model — the guards in code are the only limit,
which is consistent with the rest of the architecture. Fits 8 GB VRAM.

---

## ADR-014 · Decrypt DAVE rather than opt out of it

**Context.** Discord made DAVE end-to-end voice encryption mandatory on 2026-03-02.
`discord-ext-voice-recv` 0.5.2a179 has no DAVE support, so opus received garbage and its
router killed listening permanently after one bad packet.

**Options.** Declare `max_dave_protocol_version = 0` (the old fix) · wait for upstream ·
decrypt in-process.

**Decision.** Decrypt in-process, using the DAVE session discord.py already maintains.

**Why.** Opting out is no longer possible — the connection is rejected with close code
4017. Waiting means no voice feature at all.

**Consequences.** **E2EE stays fully on for everyone in the call** — better than the old
approach, which disabled it. Cost: a monkey-patch against an alpha library, to be deleted
when `voice_recv` ships its own. `README.md` and `PLAN.md` still describe the old
opt-out approach and are wrong.

---

## ADR-015 · Adaptation is memory-first, not reinforcement learning

**Context.** "Make her learn from me" invites an RL answer.

**Options.** RLHF / a reward model · copy Hermes Agent's auto-generated skills · a memory
ladder.

**Decision.** A memory ladder: preferences, then self-written skills, then a periodic
review pass. Fine-tuning (LoRA/SFT) only after months of real logs exist.

**Consequences.** Nothing to train, nothing to serve, and every step ships alone. Hermes
Agent (Nous Research, MIT) is a reference for the *shape*, not a dependency. The two
ladder steps are still unbuilt — [where to go next](next.md).

---

## ADR-016 · MkDocs Material for this guide

**Context.** The project is Python with no Node toolchain and no build step.

**Options.** VitePress · Docusaurus · Astro Starlight · MkDocs Material.

**Decision.** MkDocs Material.

**Why.** One `pip install`, same package manager as the code, no second language runtime
and no `node_modules`. Search, dark mode, grouped nav and Mermaid all ship built in. And
the project-specific reason: Smart App Control has already blocked two libraries for
unsigned native binaries — Node's toolchain is native binaries, MkDocs is pure Python.

**Consequences.** No Vue/React components inside pages. This guide needs diagrams and
prose, so that costs nothing.

---

## ADR-017 · Fix the query before replacing the search engine {#adr-017}

**Date.** 2026-07-30.

**Context.** Search results were poor: she called `web_search` rarely, passed the user's
whole sentence as the query, and got the same three pages back on a repeat. Two candidate
causes — a weak index, or weak queries.

**Options.**

1. Keep `ddgs`, fix the query and the call parameters.
2. Swap to a search API built for agents (Brave, Tavily) or self-host SearXNG.
3. Fan out: generate 2–3 query variants per search and merge.

**Decision.** Option 1, and only option 1 for now.

**Why.** The literature puts the win where the cheap fix is.
[Ma et al. (EMNLP 2023)](https://arxiv.org/abs/2305.14283) frame it as
*rewrite-retrieve-read* — "there is inevitably a gap between the input text and the needed
knowledge in retrieval." The
[query expansion survey (2025)](https://arxiv.org/pdf/2509.07794) puts raw → LLM-rewritten
at **+14.35 NDCG@10 / +23.43 Recall@10**, and then *"rapidly diminishing returns"*. The
first rewrite is nearly the whole benefit.

Option 3 is what those diminishing returns rule out: 1→2 queries is about **+6.7%** average
exact match and saturates by three, which does not justify tripling every search when she
already gets three tool rounds to try different angles herself.

Option 2 was measured by others, not by us —
[a 2026 benchmark of 8 search APIs](https://aimultiple.com/agentic-search) has Brave
highest (agent score 14.89, ~1 point clear of Tavily) and fastest (669 ms), with Tavily
"the cleanest default" for LLM-consumed retrieval and SearXNG free but only as stable as
your hosting. **Reviewed and deferred**, for two reasons: none of them fixes a sentence
passed in as a query, so the rewriting was needed either way; and Brave retired its
perpetual free tier in February 2026, so this is the first paid dependency in a project
that has none.

**Consequences.** The rewriter is the tool description, not a model — no training loop, no
second model in 8 GB of VRAM, no extra call per search. `web_search` stays one function, so
option 2 remains a cheap swap the day the index is the thing that's wrong.

**Caveat on the numbers.** They are reported by the cited sources on their own benchmarks,
not reproduced here. What *was* measured locally: region choice on one Thai query, and the
queries she picks across five asks (`tests/searchbench.py --live`).

## ADR-018 · Her eyes emit text, not answers {#adr-018}

**Status.** Accepted, testing state · July 2026

**Context.** She could not see images at all. Discord hands her screenshots, photos,
signs and memes, and she had nothing to say about any of them. One fact removes most of
the design space: her own model is text-only —
`deepseek/deepseek-v4-flash` reports `input_modalities: ['text']` — so vision is a
separate call whatever else is decided. The choice is what that call **outputs**.

**Options.**

1. Caption to text: an image becomes a description, the description joins the chat.
2. A native VLM answers the turn.
3. OCR for text-heavy images, plus a captioner for the picture.
4. Vision as a tool she calls with a question.

**Decision.** Option 1, with the caption conditioned on what they said.

**Why.** The goal is *react and comment*, not extract.

Option 2 loses her voice, which on a reaction turn is the entire product. A correct
observation in Qwen's register is still a failure.

Option 4 needs a trigger, and there isn't one — nobody asks a question when they drop a
meme. Her live log also shows she under-calls tools already (4 tool rows in 10 turns).

Option 3 is ruled out by memes specifically.
[Hateful Memes](https://proceedings.nips.cc/paper_files/paper/2020/file/1b84c4cee2b8b3d823b30e2d604b1878-Paper.pdf)
(Kiela et al., NeurIPS 2020) is constructed from *benign confounders* — examples built so
text-alone or image-alone gives the wrong answer, scoring models at **64.73% against
84.7% for humans**. Splitting the words from the picture rebuilds exactly the unimodal
signal the benchmark defeats.

Option 1's known flaw is named in [PICa](https://arxiv.org/pdf/2109.05014)'s own paper
(Yang et al., AAAI 2022): information lost converting image to caption, because the
caption is written before anyone asks. Here that barely bites — usually **there is no
question**, the picture is the whole message — and what remains is fixed by sending their
message along with the image. Meanwhile
[*Caption This, Reason That*](https://arxiv.org/pdf/2505.21538) found VLMs reason **better**
over their own generated captions than over raw pixels, so the text step is not purely a
downgrade. The architecture is [Socratic Models](https://arxiv.org/abs/2204.00598)
(Zeng et al., 2022) — frozen models composed through language, no finetuning.

**Consequences.** Nothing downstream learns that an image existed: it is text by the time
it reaches the brief, her rules, the log and memory extraction. The log row is
`look('meme.png') -> ...`, which the panel's existing `tool_cell()` splits with no
dashboard change. A failed look returns `""`, never an exception, and `_doing()` turns
that into her saying she cannot see — the same anti-confabulation shape as the music
guard, code-enforced.

API-only, even in `local` mode: `qwen3-vl:4b` is 3.3 GB against her ~5 GB 8B on an 8 GB
card, so ollama would evict and reload on every image. The cost of local vision here is a
load stall, not inference.

**Caveat on the numbers.** Benchmark figures are the cited sources' own, not reproduced
here. Measured locally: four real images through the live model
(`tests/eyebench.py --live`), and the ~900-character multilingual OCR that produced the
`MAX_CHARS` cap.

**Deferred.** [Typhoon OCR](https://github.com/scb-10x/typhoon-ocr) for Thai text images —
add when Thai screenshots measurably fail, not before. Local vision when the VRAM exists.
Multiple images per turn.

## ADR-019 · Reasoning stays off, on every pass {#adr-019}

**Status.** Accepted · July 2026

**Context.** Both her models can reason. `huihui_ai/qwen3-abliterated:8b` is a hybrid
thinking model and ollama exposes `think`; `deepseek/deepseek-v4-flash` advertises
`reasoning`, `reasoning_effort` and `include_reasoning` alongside `structured_outputs`.
Neither was ever switched on, and `think` was a **dead parameter on the API path** — it
existed in `chat()`, was wired to ollama, and was silently discarded by
`_openrouter_chat`, which hardcoded `reasoning: {enabled: False}`.

**Decision.** Wire `think` through to both providers so the knob is real, and leave it
**off** everywhere. Ship `TIWA_EXTRACT_THINK`, defaulted to `0`.

**Why.** Two measurements, not an opinion.

*The tool pass* (12 probes, tools stubbed, local 8B):

| | right tool | median | total |
|---|---|---|---|
| think off | 12/12 | 2,824 ms | 32.4 s |
| think on | 12/12 | **19,217 ms** | 208.4 s |

6.8× slower for no gain, on a pass a human waits through — it runs inside
`channel.typing()`, before her reply pass even starts. Worse, reasoning made it *break a
rule*: all 4/4 recall probes gained a spurious `web_search`, which the tool description
explicitly forbids ("Never for people you should just recall"). Reasoning did not help it
choose; it gave the model room to argue with the tool description.

*The write pass* (`extractbench.py --think`) — the one place latency is genuinely free,
since `memory.extract` is fired off after the reply is already on screen:

| | clean | total |
|---|---|---|
| ollama off | 5/5 | 12.5 s |
| ollama on | **4/5** | 190.4 s |
| openrouter off | 5/5 | 8.6 s |
| openrouter on | 5/5 | 19.6 s |

No gain on either provider. On the local 8B, ~15× slower **and** structured output broke:
it stored `Steven | plays | guitar},{` — raw JSON leaking into an entity name. It also
reversed a non-symmetric relation, writing `Krich | girlfriend of | Mint`, which is the
exact direction error the extraction prompt exists to prevent.

**Consequences.** The knob works now and is honest on both providers, so this is cheap to
revisit against a better model. Off stays the default everywhere.

The one structural note worth keeping: her inner pass **is** her reasoning step — a
separate call whose whole job is to think before she speaks. Enabling model reasoning
means reasoning about reasoning. And the tool miss it would have fixed was already fixed
in code by `_force_music`, which is deterministic, free, and runs in 0 ms.
[Prompts reduce, code decides](../concepts/three-passes.md) — the same rule, applied to a
knob.

**Caveat on the numbers.** Both benches were at ceiling on accuracy (12/12 and 5/5
baseline), so they can show reasoning *hurting* but could not have shown it helping. The
intermittent `play_music` miss (~1 ask in 4–6) did not reproduce at all in the 4 music
probes, and properly measuring that needs ~30 probes a side. Latency alone settled it.

**Bench gap found and closed.** `extractbench` scored `guitar},{` as **ok** — `score()`
matches by substring. The malformed-name check that catches it was added because a human
read the output, not because the bench failed. Worth remembering the next time a green
bench is treated as proof.

## ADR-020 · Inject what she knows; stop waiting for `recall` {#adr-020}

**Status.** Accepted · July 2026

**Context.** An audit of the real database showed five apparent problems: the tool pass
almost never called tools (5 calls in 11 turns, **zero** `recall`, **zero** `web_search`),
the forced music retry was firing as often as the model, the graph held 4 entities and 2
relations, one of those entities was `Marvel Rival` where every turn said `Marvel Rivals`,
and `episodes` was empty so `idle()` could never fire.

**Decision.** Three code changes, and two of the five "problems" written off after
measurement.

**Why — what the measurements actually said.**

*The tool pass is fine.* Hypothesis: eight lines of conversation history degrade tool
selection, the way [Lost in the Middle](https://aclanthology.org/2024.tacl-1.9/)
(Liu et al., TACL 2024) degrades retrieval. **Refuted** — 8/8 right tool with history and
8/8 without, same probes. Then reading the 11 turns settled it: every one was a music
request. No turn needed `recall` or `web_search`. The low count was correct behaviour on
an unrepresentative sample, and the forced-retry rows are the guard working, not the model
failing.

That leaves the real defect underneath: **`turn_context()` read episodes only**, and pass
3 is told an episode is "almost always null", so it returned `""` on every turn ever
recorded. A stored fact could only be reached by the model *choosing* to call `recall`.
Memory was write-only. It now injects the speaker's facts directly — the same trade as
[ADR-012](#adr-012), and for the same reason: what she should already know is not worth a
round-trip. `recall` keeps its job for third parties.

The fix also dissolves the first "problem": with a populated graph, `recall` fires
unprompted on the very next live turn. **#1 was a symptom of #3.**

*Entity canonicalization.* `canonical()` folds near-duplicates with stdlib `difflib` at a
0.85 ratio. [CESI](https://arxiv.org/abs/1902.00172) (WWW 2018) does this properly by
clustering learned embeddings with side information; at this scale a string ratio is the
whole win. Fewer tools is a real lever too — an adaptive policy showing ~7 tools instead
of 50 lifted selection from 87.1% to 93.1% on
[BFCL](https://proceedings.mlr.press/v267/patil25a.html) — but with selection measured at
8/8 there is nothing here to buy.

*The idle heartbeat could never fire.* `idle()` returns `""` when its fuel is empty, and
its fuel was episodes, which are always null. `recent_episodes()` became `idle_fuel()` and
falls back to the newest facts. Timing is the hard part of a proactive agent — fixed rules
produce untimely, annoying messages ([Liao et al., SIGIR 2023](https://dl.acm.org/doi/10.1145/3539618.3594250))
— so the brakes stay where they were: ≥ 3 h apart, 09:00–23:00, and she is told to output
NOTHING on most ticks.

**Consequences.** She opens every turn knowing who she is talking to, at the cost of up to
12 lines of prompt. Proven live: asked in Thai which games her father plays, she answered
from seeded facts she was never told in the conversation — including a stored `note` — and
asked a follow-up.

**Caveat.** The 11-turn sample is small and was all one activity. "The tool pass is fine"
means fine on 8 probes and on 11 music turns, not fine in general.

## ADR-021 · Anchor the extractor, then give the bench its teeth back {#adr-021}

**Status.** Accepted · July 2026

**Context.** The graph stayed almost empty through 11 real turns. `ไอภพ` was named in four
of them and never stored. Separately, every bench sat at ceiling — 8/8, 12/12, 5/5 — so
nothing could show a fix working.

**Decision.** Fix extraction at the input, move two guards from prompt to code, and add
probes that fail.

**Why.** Tracing one real turn found the whole bug in one line: the model **romanized**
`ไอภพ` to `Iop`, `_grounded()` could not find `Iop` in the Thai text, and a true fact was
dropped. The guard was right; its input was wrong.

That is the failure mode
[AEVS](https://www.mdpi.com/2073-431X/15/3/178) describes — hallucination comes from an
unconstrained generation space, and the fix is to tie every element to a span of the source
*before* extraction rather than filtering after. The cheap version of that is one rule:
copy every name character-for-character in its own script, never romanize. `ไอภพ | plays |
Blade` stored on the next run.

Two more guards moved to code after prompting demonstrably failed:

- **Role direction.** `Krich | girlfriend of | Mint` says Krich is the girlfriend. The rule
  *and the exact wrong example* were already in `_EXTRACT_SYSTEM` and the model reversed it
  anyway. `_role_swap()` fires only when the relation ends in " of", the subject is the
  speaker, and the text literally introduces the object as the speaker's something.
- **Self-relations.** `Nara | owes | Nara`, invented from her own reply. Forbidden in the
  prompt, emitted anyway, rejected in code now.

**The benches had no discriminative power.** When a benchmark is easier than the system,
pass rates saturate near 1 and models of very different capability produce indistinguishable
numbers ([arXiv 2602.16763](https://arxiv.org/html/2602.16763v1)); the answer is harder
items, the MMLU → MMLU-Pro move. `extractbench` gained three probes that all failed when
written — the Thai name, a forbidden reversal, and her enthusiasm treated as fact — plus
checks for forbidden directions and self-relations. It went 5/5 → **6/8** on the first run
and back to 8/8 only after the fixes landed.

**Consequences.** Two of the checks exist because a human read the output, not because a
bench failed: `guitar},{` and `Nara owes Nara` both scored **ok**. A green bench is evidence,
not proof.

**Measured and rejected.**

- *A bigger vision model for Thai.* `qwen3-vl-32b-instruct` is cheaper per token than the
  8B ($0.104/M vs $0.117/M), so it looked free. Across two runs on the same sign it was
  better once and worse once, while costing **4.2× the latency** (7,385 ms vs 1,744 ms) on
  a call that blocks her reply. Run-to-run variance on one image is not evidence. Keeping
  the 8B; [Typhoon OCR](https://github.com/scb-10x/typhoon-ocr) stays the real upgrade.
- *Folding `Gojo` into `Gojo Satoru`.* Tempting at 0.62, but the same containment rule
  merges `Blade` with `Blade Runner`, and a wrong merge is unrecoverable. `lookup()` already
  matches substrings both ways, so the pair already **reads** as one. Two nodes, one answer.
- *difflib for relation names.* Disqualified by measurement: `likes`/`dislikes` scores
  **0.769** while `plays`/`playing` scores **0.667**, so every cutoff that folds the pair we
  want also merges a relation with its opposite. A 4-character stem of the first word
  separates them cleanly.

## ADR-022 · Episodes fire on surprise, not on the model's judgment {#adr-022}

**Status.** Accepted, August 2026.

**Context.** The live database held **2 episodes across 97 logged turns** — and both
were written on the same calendar turn, one a restatement of the other. Pass 3 is told
*"episode: almost always null"*, backed by four BAD examples and one GOOD, and it obeyed
almost absolutely. So `turn_context()`'s episode lines were effectively dead, and she
knew facts about people while having essentially no memory of anything happening —
semantic memory without episodic memory, in
[Tulving's](https://doi.org/10.1037/h0080017) split.

The two that *did* land are the tell. The prompt forbids an episode for "someone asking a
question" and for "anything already captured as a memory above"; those two rows are a
question, and each other. The gate was not merely too tight — it was **miscalibrated**,
silent for 95 turns and then wrong twice on one.

**Decision.** Stop asking a model *"would this matter in a month?"* — a judgment call
it always declines — and decide in code from whether the turn **moved the graph**: a
subject she had never met, or a belief that flipped. Both signals are already computed
inside `store_extraction()`, so it costs no extra call.

This is what event segmentation theory says the brain does: cut memories at
**prediction errors**, the moments the pattern broke
([Neurosci & Biobehav Rev](https://www.sciencedirect.com/science/article/abs/pii/S0149763424000010)).
[EM-LLM](https://arxiv.org/abs/2407.09450) (ICLR 2025) segments a token stream by
Bayesian surprise and beats full-context models on LongBench, which is the same idea one
level down. A model-written episode still wins when one appears; it just no longer has
to.

**Consequences.** Measured **4 of 12** turns on a replay, and 3 of 4 on a live
conversation. The rate falls on its own as the graph fills — new people get rarer, only
flips remain. Three narrowing rules each came from reading real output rather than from
a failing check: objects don't count (or every game ever named is a life event), the
speaker doesn't count (his own facts are already in her context), and freshness is judged
against a snapshot taken **before** the batch — live, `Steven plays guitar` read as old
news because `Krich cousin of Steven` had invented him one line earlier in the same turn.

**Rejected.** Lowering the prompt bar instead. The prompt bar *is* the mechanism that
failed, and the project rule is the same one that settled the guards, `now_playing` and
role direction: **prompts reduce, code decides.**

## ADR-023 · A new belief replaces the old one {#adr-023}

**Status.** Accepted, August 2026.

**Context.** The primary key is `(src, rel, dst)`, so `Tycoon likes X` and `Tycoon hates
X` were two valid rows. Both survived, both were injected every turn, and she read a flat
contradiction and picked one at random. `canonical_rel()` deliberately keeps opposites
apart as *names* — that is correct and measured — but nothing ever retired the loser.

**Decision.** `_supersede()`: relations that are two answers to the **same question**
compete for one (subject, object) pair, and the newer one wins. One hand-listed axis
(`feel`: like/love/enjoy/prefer vs hate/dislike), with polarity, so a genuine flip is
reported and a refinement (`likes` → `loves`) is not.

**Consequences.** Verified live — "Steven loves durian" then "Steven hates durian now"
leaves one row and one episode. `plays` and `likes` between the same pair are untouched:
different questions. This is also the half of the forgetting literature that applies at
her scale; **decay engines are not**, at nine facts. See
[open questions](../open-questions.md).

## ADR-024 · Reflection rides the heartbeat that was already running {#adr-024}

**Status.** Accepted, August 2026.

**Context.** `idle_turn()` wakes every 30 minutes from 09:00–23:00 — about **28 model
calls a day** — and is rate-limited to *speaking* once every 3 hours. The overwhelming
majority of those calls ran, decided "nothing to say", and were discarded. That is
thinking time already bought and thrown in the bin.

**Decision.** `pipeline._settle()` gives the tick a second job. Once `REFLECT_EVERY = 3`
episodes have piled up unprocessed, it reads them and writes back one conclusion.

- **Reflections are episodes filed under her own name**, so they land back in the stream
  they were drawn from — `idle_fuel()` retrieves them like anything else she lived, and
  the newest one dates the watermark for free. No new table.
  [Generative Agents](https://arxiv.org/abs/2304.03442) stores reflections back into the
  same observation stream for the same reason.
- **It gets the expensive model.** Nobody is waiting on it, which makes it the one pass
  where latency does not matter — the argument
  [Letta](https://www.letta.com/blog/sleep-time-compute/) makes for sleep-time agents.
- **It fires only on a backlog**, so a quiet day costs zero calls.

**Consequences.** Live output on a four-turn conversation: *"Krich is always the one
telling me about other people, but I still don't know what he himself thinks about
anything."* No single turn contained that.

A reflection that concludes nothing still writes a **blank row** as the watermark, or the
same three episodes are re-reflected every half hour forever; `idle_fuel()` and the panel
filter `text != ''` so it never reaches her as something she lived. A reflection that
**fails** deliberately does not watermark — the events stay unreflected and the next tick
retries, rather than a provider outage silently eating her week.

**Depends on [ADR-022](#adr-022).** With zero episodes this pass reflects on an empty
room; that is why episodes shipped first.

## ADR-025 · The calendar needed a prompt, not code {#adr-025}

**Status.** Accepted, August 2026.

**Context.** Reported as "she notes it in the database but calls no tool". The live log
shows exactly that:

```text
Tycoon: พรุ่งนี้เช้ามีนัดกินข้าว 13.00 ช่วยลงปติทินให้หน่อย
ทิวา:   ...มึงหมายถึงพรุ่งนี้ (อาทิตย์ 2 ส.ค.) 13.00 ป่าว     ← a fair question
Tycoon: ช่ายๆๆ                                              ← yes
ทิวา:   โอเค ลงให้ละ อาทิตย์ 2 ส.ค. 13.00                    ← claims the write
```

No `calendar_write` row. Same shape as the music confabulation
([ADR-012](#adr-012)): she narrates an action she never performed.

**Investigated, and the obvious suspect was wrong.** Both calendar tool descriptions say
*"Krich's calendar"* / *"his schedule"* while the asker was Tycoon, which looked like the
cause. `tests/calbench.py --live` says no — Tycoon and Krich behave identically on every
case, twice. Don't fix what the data cleared.

**Measured cause.** `_INNER_SYSTEM` spent four lines on music and one word on the
calendar: *"check the calendar"*. Nothing in the prompt described writing at all, so a
message leading with a calendar word mapped to `calendar_read`. Reproducible: 0/2 on the
bare confirmation, 0/2 on `ลงปฏิทินให้หน่อย นัดหมอฟัน…`, ~50% overall.

**Decision.** Add the missing rule to `_INNER_SYSTEM` rather than build a
`_force_calendar()` mirroring `_force_music()`. **20/21** across three runs afterwards,
from ~50%.

This is the ladder working in the direction it usually doesn't. The project rule is
*prompts reduce, code decides*, and four ADRs record a prompt failing and code fixing it —
but that rule is about **guards**, where the cost of a leak is unbounded. Here the prompt
had simply never been written. Reaching for a forced retry first would have added a model
call per calendar turn to compensate for a sentence nobody wrote.

**Consequences.** ~95%, not 100%, and the residual is always the bare confirmation. If it
recurs in real use the answer is the one music already took — a forced retry — and the ✅
gate makes that safe to over-fire, since a wrong queue costs one ❌. `calbench.py` asserts
`>= 6/7` so the regression is caught rather than rediscovered from a log.

**Also found.** `gcal.apply_change()`'s parse is solid and needed nothing: Thai titles,
relative dates, and even a Buddhist-calendar year (`2569` → `2026`) all resolve correctly.
The stage everyone assumes is fragile was fine; the stage nobody documented was broken.

## ADR-026 · Mini Tiwas, and dispatch in front of her voice {#adr-026}

**Status.** **Superseded in scope by [ADR-028](#adr-028)**, which removed the knob and made
this the only turn shape on the `swarm` branch. The decision below stands; only "behind a
flag, not the default" is out of date. Full plan, gates and numbers in `SWARM.md` at the
repo root; this entry is the decision, not the record.

**Context.** [The tool registry](../concepts/tools.md) had already recorded its own
ceiling — *"every tool you add competes with `play_music` for attention"* — and a working
tool, `now_playing`, was deleted to protect the others. Home Assistant is next with five
or six more. Separately, her own log said a turn took **6,431 ms p50** while the tools
themselves ran in **3 ms**: the cost was deciding what to look up, not looking it up.

**Decision.** Split *what* from *how*. Main Tiwa dispatches a goal in one phrase; small
single-purpose [Mini Tiwas](../concepts/the-swarm.md) work out the rest and return
declared facts. The tool pass leaves that path entirely — `recall` becomes a sqlite scan
(`memory.mentioned()`), music becomes DJ Tiwa, search and calendar become minis.

**Measured, live, on real turns.**

| | serial | concurrent |
|---|---|---|
| turn latency p50 | 5,059 ms | **2,695 ms** |
| routing accuracy, 111 hand-corrected turns | 70.3% | **94.6%** |
| false positives on turns needing nothing | 6.2% | 12.5% |
| persona, blind pairwise A/B | 4 wins | 3 wins, 5 ties |
| what Main Tiwa reads to handle music | 1,643 chars | **312 chars** |

Adding a fourth mini changed Main Tiwa's prompt by **0 characters**. That was the bet.

**The one reversal.** Dispatch was supposed to run *beside* her reply, and did, until it
was measured: asked *"who won the premier league last night"* she answered *"Man City.
2-1. Haaland scored both"* — invented — because nothing in her state block said a lookup
was running. **She cannot decline to answer something she does not know is being looked
up.** Dispatch moved in front of the persona call. It costs almost nothing, because the
turn was already bounded by dispatch-plus-mini rather than by her words. The *work* still
never blocks her; only the routing decision does.

**Consequences.** Three new deadlines, each from a real failure — one live turn ran 507
seconds on a stalled search held through `asyncio.run`'s executor shutdown. The router
over-fires on short Thai (12.5% against 6.2%), which costs a spurious song. And in 111
real turns there was **not one true Search Tiwa case**: all eight logged `web_search`
calls were the old system identifying a track before playing it, which DJ does itself now.

**Not adopted.** `note_provisional`, the one proposed write path, was never built —
[the guards](../concepts/guards.md) are the reason offline reflection is the only thing
that changes a belief, and a runtime writer would need its own guard chain first.

## ADR-027 · A fact has to be worth a row, not just true {#adr-027}

!!! warning "The convert rule below was wrong — see [ADR-030](#adr-030)"
    The axis this ADR added is right and stands. Its *mechanism* — convert a
    one-off action into the taste underneath rather than dropping it — turned
    out to be a fact factory, measured on the real graph three days later.
    A request writes nothing now.

**Status.** Built and measured live. `tests/worthbench.py`.

**Context.** The extractor tested one thing: is this fact **true**? Every guard in
[the guards](../concepts/guards.md) is a truth guard — grounded in what the user said,
correctly directed, not her own invention. `Tycoon requested ATLAS-The Score` passes all
of them and is useless a week later. Her graph filled with rows like it until eight of
Tycoon's twelve facts were song requests, crowding *"mains nobody good, blames the team"*
toward the `TURN_FACTS = 12` cap. A notebook about people had become a queue history.

**Decision.** Add a **worth** test, and phrase it as *convert*, never as *skip*.

That phrasing is not a preference. `store_extraction()`'s own docstring records what
happened when episodes were asked *"would this matter in a month?"* — the model answered
null **100% of the time**, so half her memory never existed. A bar phrased as "skip unless
important" would have done the same to facts. Phrased as *"an action reveals a taste,
write the taste"* it has something to produce instead of something to withhold.

| they said | before | now |
|---|---|---|
| `play venom - eminem` | `Maa Yan requested venom - eminem` | `Maa Yan likes Eminem` |
| `ขอเพลงจากเกม Blue Archive` | `Krich requested เพลงจากเกม Blue Archive` | `Krich likes Blue Archive` |
| `เปิดเพลงอะไรก็ได้` | a row | nothing — it reveals nothing |

**Measured.** 4/4 converted on the real turns that produced the deleted junk. `factbench`
on the API path: **0 invented facts, 0 real facts missed** — that second number is the
refusal failure, and it did not happen.

**Also decided: every guard rejection is logged.** Six guards dropped silently, which made
a working filter and one quietly eating true facts identical from the outside. You cannot
tune a bar you cannot see. `kind='memory'` rows name the fact and the rule that killed it.

**Found by replaying 25 real turns before trusting any of it.** The first version produced
`Tycoon likes ATLAS [requested ATLAS-The Score]` — the junk had not gone, it had moved
into the `note` field, along with the model's reasoning about its own conversion. *"THE
NOTE IS THE BEST PART"* read as an invitation to fill it. The note rule now says what a
note is **not**, and a URL or video id joins dates as never-an-entity: `likes the song at
gVQzCR5h4Y8` is not a thing anyone likes.

**Rejected: a closed relation vocabulary.** Proposed, then tested against the real graph
and withdrawn — it leaks both ways, since `wants` is correct for *"Krich wants a PS5"* and
wrong for *"wants to listen to this song"*. And by
[ADR-025](#adr-025)'s reasoning, *prompts reduce, code decides* is a rule about **guards**,
where a leak is unbounded; a cluttered graph is bounded, visible, and one click to delete.
A blocklist stays available and starts **empty** — add a stem when the drop log shows the
same junk verb three times, the growth policy `_AXES` already states for itself.

**Deferred.** Ranking facts by how often they are actually retrieved, so importance is
proven by use rather than guessed at write time. It wants a week of drop-log data first.

**Not fixed by this.** `Krich` has no facts at all — his turns are music asks with no
nameable artist, so there is nothing about *him* to convert. That needs her to ask, which
is a different change.


## ADR-028 · Two branches, not one codebase with a knob {#adr-028}

**Status.** Done on `swarm`. `main` is untouched and stays the serial version.

**Context.** [ADR-026](#adr-026) shipped the swarm behind `TIWA_TURN`, defaulting to
`serial` so it could prove itself first. Four months later the log said what actually
happened: **1 `mini` row in 131 real turns**, and that one a dispatch timeout from a test
session. The swarm was built, benched, measured, documented — and never once ran in a
real conversation. A default that nobody changes is a feature that does not exist.

Meanwhile both shapes had to keep working, which is a real tax: every prompt fix landed
twice, `_state()` carried an `inner` parameter that one path always passed empty, and
`growthbench` had to assert things about a file the other path did not use.

**Options.**

1. **Flip the default to `concurrent`.** Cheapest. Keeps both paths, keeps the tax, and
   leaves the serial code as an untested fallback nobody would notice rotting.
2. **Delete serial from `main`.** One version, no way back, and the control arm for every
   future persona A/B goes with it.
3. **One version per branch.** `main` keeps the tool registry; `swarm` deletes it. Both
   stay runnable, and comparing them becomes `git checkout`.

**Decision.** Option 3. The two shapes were always two *versions*, not two settings — the
flag was scaffolding for a migration that has finished.

**Consequences.**

`pipeline.respond()` **is** the concurrent turn now; `turn.py` folded into it, because a
delegate with one implementation is an indirection and nothing more. Gone with the knob:
`TOOLS`, `@tool` and every description written for a model to read, `_tool_chat`,
`_inner_brief`, `_arg_name`, `_force_music`, `_TERMS_SYSTEM`, and the `recall` and
`calendar_read` tools — replaced by a sqlite scan and `gcal.upcoming()`, neither of which
ever needed a model to decide it. Net **−671 lines**.

`tiwa/tools.py` keeps the two things still load-bearing: the `Turn`, which `bot.py`,
`chat.py` and `dashboard.py` drain unchanged, and eight **actuators** a mini reaches for
once it has already decided. They no longer carry prose for a caller that no longer
exists.

**Two things had to move rather than die.** `idle()` ran on the tool loop so she could
search something she cared about — it never once did, so it is a plain call now, with
one `minis.run()` as the upgrade path. And `join_voice`'s *return string* was how she
knew `TIWA_VOICE=dj` means she cannot join; nothing reads a return any more, so
`_asked_voice()` returns `"dj-only"` and `_doing()` says it. Inert was never the
requirement — inert **and honest** was.

**The A/B moved with it.** `latbench` and `personabench` used to flip the knob inside one
process. They take a `--tag` and two files now: run `latbench` on each branch, hand both
to `personabench`. The comparison got more honest, not less — it is measuring the thing
that actually ships.

**The gap it shipped with, and how it closed.** The loose Thai prefixes in
`_MUSIC_VERB` (`"ขอ "`, `"เปิด "`) sat behind `_force_music`'s NONE veto on the serial
path; DJ Tiwa's `none` became that veto but landed *after* `_doing()` had already told
her a song was coming. It was written down as accepted — and then it fired in the first
real Discord session, on `"ขอ ยืมตังหน่อย"` (lend me money), exactly as predicted.

**Closed 2026-08-24.** `respond()` now awaits DJ's verdict before building the state
block. It is nearly free: DJ starts at t=0 alongside dispatch and both are the same model
(measured that session, dispatch 1.3–1.9s against DJ 1.3–1.9s), so it costs the gap
between two things already running, on music turns only. Quiet turns start no DJ and wait
for nothing.

The bigger win was not the veto. `queued` is filled in by the time she is briefed, so she
is told *"you have just done this: play Spiderman"* instead of *"putting on what they just
asked for"* — grounded in the words **they** used, which is the only thing she may repeat
before the search returns. `forkbench.dj_has_the_last_word_before_she_speaks` fails on the
old ordering.

**One behaviour differs from `main`, deliberately.** A bare agreement after her own
clarifying question — `"ช่ายๆๆ"` — used to reach `calendar_write`. The dispatch prompt
drops bare agreements, because that is what cut router over-firing from 43.8% to 12.5%.
`calbench --live` expects 5/7 here against `main`'s 7/7 and says why.

**Measured after.** 21 offline benches green, 5 module self-checks, and 8 live
conversation turns: no mini fired on a turn that needed none, coercion bounced,
escalation answered, Thai stayed Thai.


## ADR-029 · The music trigger stops deciding and starts guessing {#adr-029}

**Status.** Done. The precision it gave up moved into DJ Tiwa's prompt, where it is
measured live.

**Context.** `_missed_music()` was a careful phrase classifier: exact phrases, verbs
anchored to the start of the message, a trailing space to separate a foreign song title
from ordinary Thai, and a question veto over the top. Every rule was earned by a real
failure, and together they made it narrow.

Measured against her own log, that narrowness cost 25 real music asks:

| she said | why it missed |
|---|---|
| `skip` ×4 | a bare verb matched no phrase |
| `เปิดSunflowerให้หน่อย` | no space after `เปิด` |
| `hero miliเล่นให้หน่อย` | the verb was not at the front |
| `ไม่ใช่ ของMili` (*no, the Mili one*) | no music word at all |
| `มันจบแล้ว เล่นอีกรอบ` (*it's over, play it again*) | mid-session reference |

It had to be careful because on the serial path whatever it matched went **straight to
`play_music`** with nobody to check it. It was the decision.

**It stopped being the decision, and nobody noticed.** DJ Tiwa reads the whole message
with the deck in front of it and answers `none` when it is not a music ask; since
[ADR-028](#adr-028) that verdict arrives *before* she is briefed. The classifier's only
remaining job is starting DJ at t=0 beside dispatch rather than ~1.5s behind it. It buys
latency, nothing else.

**Decision.** Invert the trade. `_maybe_music()` is greedy: any hint word anywhere, in
either language, no anchoring — plus **"something is already playing"**, which is what
reaches `skip` and `ไม่ใช่ ของMili` and every other mid-session reference that carries no
music word at all.

`route()`'s NET went with it. It force-added `dj` whenever the classifier fired, and it
had been dead in production since ADR-028 — `respond()` passed `dj_already_running=True`
on exactly the turns that would have triggered it. It survived only to make the bench
agree with a system it had stopped modelling.

**Consequences.**

A false positive is now one cheap call that answers `none`, writes nothing, and never
reaches her. *"my dad plays Warframe"* does start DJ. That is fine — and it is also the
whole risk, so it is measured rather than assumed.

**`djminibench --live` is the new load-bearing check**, and it earned its place on the
first run by catching DJ answering `play` with terms `"Warframe"` to that exact sentence.
The old anchoring had been hiding it. DJ's prompt now says a stated fact is not a request,
and that `play` about a game, a sport or an instrument is not music. 14/14, with the 8
non-music asks all vetoed and none reaching the deck.

One regression came out of that same fix and the bench caught it too: the first wording
asked *"are they asking to HEAR something?"*, and `หยุดเพลง` (stop the music) is not — so
DJ said `none` to a stop. The question is now *"are they asking you to do something to the
music"*, with wanting it off named explicitly.

**The measured numbers moved, and one of them is honest rather than better.**
`dispatchbench` used to grade the router and the classifier as one figure — 94.6%. Scored
apart it grades the router alone: **~80% on `dj`**, with false positives on turns needing
nothing dropping from 12.5% to 6.2%. Neither describes her, so the bench now also prints
*"of the N `dj` asks the router missed, the free hint catches M"* — so far M is always N.

**What stayed precise.** `_DECK_Q`, because it *prevents* an action. A guess that acts is
unbounded; a guess that declines costs a repeated question.


## ADR-030 · A request is not a preference, and a taste needs evidence {#adr-030}

**Status.** Done. [ADR-027](#adr-027)'s convert rule is withdrawn; its axis stands.

**Context.** ADR-027 added the right question — *is this fact worth a row?* — and answered
it with the wrong mechanism. Refusing outright was the failure this project had already
hit once (episodes were asked "would this matter in a month?" and the model answered null
100% of the time), so the rule said: **do not drop a one-off action, CONVERT it** into the
durable taste underneath, preferring the wider name — the artist, not the track.

The model obeyed the first half and ignored the second. Three days of real traffic later,
the graph:

| | Jul 31 – Aug 22 (3 weeks) | **Aug 23 – 25 (3 days)** |
|---|---|---|
| facts written | 11 | **13** |
| carrying a note | 3 | **0** |
| shape | names, friendships, games | 12 × `Tycoon likes <a song he asked for once>` |

15 of 22 facts were `likes`. 19 of 22 had no note. The drop log — the instrument ADR-027
added to make the bar visible — held **one row**, because almost nothing was being
rejected. And a second rule of mine made it worse: *"Leave [the note] EMPTY unless they
said something worth quoting"*. So the graph filled with unjustifiable preferences and
then could not explain any of them.

What she was handed about one person, every turn: twelve lines, seven of them songs he
had requested once, with `TURN_FACTS = 12` about to start pushing the real ones out.

**Decision.** Three changes, in the order they matter.

1. **A request writes nothing.** Not a taste, not a weaker taste. The song played and the
   activity log says so; her beliefs are not a log.
2. **A taste needs evidence, and there are exactly two kinds.** Either they SAID it — a
   preference word from a person, checked in code against their actual message — or the
   note says why it matters. `likes` / `hates` / `interested in` with neither is dropped
   and logged. Every other relation (`real name`, `plays`, `cousin of`) needs neither: a
   relationship justifies itself, a taste has to.
3. **Her own stances are exempt.** They already pass three harder guards, and the evidence
   for them is the sentence she just said.

**Consequences.**

The note requirement came first and was a *proxy* for evidence. `factbench` caught the
proxy failing at the edge: *"Mint hates coffee btw"* was dropped for carrying no reason,
when the person had just said it out loud. So the code now measures the thing itself —
`_stated_taste()` looks for a preference word in what they typed, with `"I'd like you to
play X"` stripped first, because every polite music ask is phrased that way.

**The prompt swung too far before it settled, and only the benches showed it.** With
"WRITE NOTHING AT ALL" in front of it, the extractor started dropping whole turns that
were *both* a request and a fact — `extractbench` went 8/8 → 6/8, losing
*"หาเพลงเปิดให้หน่อย ไอภพกำลังเล่นBlade"*, where the song is noise and *ไอภพ plays Blade* is
not. The rule now says explicitly that it covers the request, not the message. Back to
8/8.

`worthbench` had to be rewritten, because it was asserting the rule being withdrawn — it
required a music ask to *become* a taste. Its docstring keeps the history, since a bench
that was confidently wrong for three days is worth remembering. Its `keeps()` now makes
two attempts per case, not out of leniency but to tell "the bar is wrong" from "the model
wobbled" — measured while writing it, a Thai stated preference landed 2 runs in 3.

**Measured after.** `factbench`: 0 invented facts, 0 real facts missed.
`extractbench`: 8/8 twice. `worthbench`: 6/6 music asks write nothing, 4 bare tastes
dropped with reasons logged, structural facts and stated preferences all survive.
22 benches green.

**The existing graph was cleaned to match**, backed up first: 22 facts → 8, 24 entities →
10. Fourteen went, twelve of them one-per-request from the convert era. Two predated it
and were the same shape; they are in the backup if they turn out to have been real.

**Not fixed by this.** `Krich` still has no facts at all — his turns are music requests
with nothing else in them, and this ADR makes that stricter, not looser. That needs her
to ASK, which is a different change. And ranking facts by how often they are actually
retrieved is still deferred — the drop log finally has something in it now, so there will
be data to do it with.


## ADR-031 · Repetition is evidence, counted where it already lives {#adr-031}

**Status.** Done, and it is the half [ADR-030](#adr-030) knowingly left open.

**Context.** ADR-030 gave a taste exactly two ways in: they SAID it, or the note says
why it matters. Both are judged inside a single turn — and that is precisely why a real
taste shown by *behaviour* cannot get in. Somebody who asks for the same artist every day
is telling her something, but each of those turns, on its own, looks exactly like the junk
ADR-030 had just removed. Judged one at a time, the honest answer to every one of them is
"nothing".

**Options.**

1. **Loosen the per-turn rule.** No — that is the convert rule again, and it has already
   been tried and measured.
2. **Count occurrences in a new table.** A `sightings` table, a counter per (person,
   thing), promote at N. Correct, and it stores a second copy of something already on
   disk.
3. **Count what is already logged.** `mini` rows carry the search terms DJ Tiwa chose;
   the `turn` row that follows one carries the author. Pairing them is the same trick
   `dispatchbench` uses to mine its labels.

**Decision.** Option 3, on the heartbeat, beside `_settle()` — the sleep-time slot that
already exists and is already described as thinking time bought and thrown away. Nobody
is waiting, so the pass is free in the only sense that matters.

**Consequences.**

The evidence for every fact it writes is rows you can read on the activity page, which is
a stronger property than it sounds: *"asked for Charlie Kirk three times (with a spelling
variation)"* can be checked against the log by hand.

Four guards, all code:

- **≥ 3 asks or no call at all.** Twice is a coincidence, and a model asked to find a
  pattern in two things will find one.
- **Never a fact about her.** This pass is the one door that could open the coercion
  guarantee — a user repeating "play BLACKPINK" enough times must not become a belief of
  hers. `tastebench` drives exactly that attack.
- **The note is the evidence**, so an empty one means no row. A conclusion that cannot
  name what recurred did not find a pattern, it guessed one.
- **A watermark**, as a `kind='taste'` log row. Without it she re-concludes the same fact
  on all 28 heartbeat ticks a day.

It does **not** go through `store_extraction`, and that is deliberate rather than lazy.
Those guards are built for "extract from one message": `_grounded()` would reject every
widened name here, because *"superhero film scores"* appears in no message anyone sent.
Different evidence needs a different door — but the door is narrow, and the four guards
above are what make it so.

**Measured.** On her real log it read 11 scattered asks from one person and wrote one
fact — `Tycoon likes Charlie Kirk`, from three asks including a misspelling — while
correctly declining to invent a genre for the one-off superhero themes. `tastebench
--live` is 5/5: a repeat becomes a taste, a spelling variation is counted together, three
tracks from one franchise widen to the franchise, and both a scatter and a
pattern-of-only-two write nothing.

**Still not fixed.** `Krich` has no facts. He asks for music and says almost nothing else,
so nothing here helps — the answer is her ASKING, which is a different change and the
more interesting one.


## ADR-032 · She asks, because some people never say anything {#adr-032}

**Status.** Done. The last of the three memory gaps, and the only one no rule about
*storing* could have closed.

**Context.** [ADR-030](#adr-030) decides what to keep from what someone says.
[ADR-031](#adr-031) counts what they repeat. Both are useless against a person who does
neither: `Krich` had talked to her for a month, and the graph held **zero facts about
him**, because every one of his turns is a music request with nothing else in it. Nothing
stated, no pattern to count. Under the rules as written, she was never going to know one
thing about the person who owns her.

The prompt already told her to ask when she wanted to know something. She never did — and
the reason turned out to be the same bug as the empty deck. `turn_context()` returns `""`
when it knows nothing, so a stranger and an old friend hand her **the identical silence**.
She had no way to notice the gap, so she never filled it.

**Decision.** Tell her, in code, on the turns where it is true. `memory.should_ask()`
gates it; the question itself is entirely hers.

**Consequences.**

Four guards, all code:

- **Under `KNOW_LITTLE` (3) facts.** Two facts is still a stranger.
- **Not again for `ASK_EVERY` (8) of THEIR turns.** A question every turn is an interview,
  which the persona rules forbid by name — *"แล้วมึงล่ะ"*, *"what about you?"*. The
  cooldown counts that person's turns, so a busy channel cannot burn down a quiet
  person's timer.
- **Never about herself.**
- **A declined nudge costs nothing.** The cooldown counts questions she *asked*, not
  nudges she was given.

That last guard came out of watching it work. She ignores the nudge on a bare `hey` and
on `skip` — and she is **right** both times; *"what do you do for work?"* mid-skip is not
a friend talking. Burning her one chance in eight turns on a turn that could never have
worked was the real bug, and the fix was to stop treating a nudge as an ask. `_is_question()`
is deliberately over-eager, because a false positive there makes her ask *less* often.

**Naming the shape of the question is what made it work at all.** The first version said
*"ask ONE real question about themselves"* and sat mid-paragraph. Measured 3/5, and every
one of the three was about the **moment** — *"มึงเบื่ออะไรล่ะ"*, *"what's up?"*,
*"skip what?"*. That is precisely the reflex filler the rules above already forbid, with
a question mark on it. The nudge now goes last in the block and lists the shape
(`มึงทำงานอะไร`, `เล่นเกมอะไรอยู่`, `who do you actually play with`) while naming the
filler it must not be.

**Measured, six turns as a stranger:** she asked on turn 1 — *"Mili เนี่ย มึงชอบเพลงไหน
ของเค้าเป็นพิเศษ"*, tied naturally to the song he had just asked for — and then said
nothing more about it for five turns. And the loop closes: his answer is a *stated* taste
with the reason attached, so `ชอบ hero มากสุด ฟังมาตั้งแต่ ม.ปลาย` stores as
`Krich likes hero — ฟังมาตั้งแต่ ม.ปลาย`, and `ทำงานเป็น dev` stores as `Krich works as dev`
with no note needed at all.

**What this is not.** It is not a curiosity mini and it should not become one. The dead
`ask` field on the dispatch router already recorded why — she is better at asking than a
router is, and she has the whole conversation to ask from. Code decides *whether*; she
decides *what*.
